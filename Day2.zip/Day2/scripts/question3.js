let age = prompt("Could you please confirm your age");

let drink ="Can Drink";
let nodrink ="Cannot Drink";

if (age>21){
    console.log(drink);
}else{
    console.log(nodrink);
}


