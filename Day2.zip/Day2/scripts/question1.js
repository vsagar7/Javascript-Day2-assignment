let name = prompt("What is your name");
console.log(name);

// let boy=confirm("are you a boy?");
// console.log(boy);